# django_web_sockets
Using web sockets in Django using Django channels
